export interface EventVerification {
    code: string;
    id: string;
  }