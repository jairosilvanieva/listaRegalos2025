export interface Guest {
    id?: string; 
    nombre: string;
    apellido: string;
    dni: string;
    eventId: string;
  }