export interface Event {
    id: string;
    eventType: string;
    location: string;
    date: string;
    time: string;
    description: string;
    code: string;
    userId: string;
  }
  